package com.example.newproject



import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModel


class NotesViewModelFactory (private val dao: NotesDAO,private val dao2: StudentDAO)
    : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(NotesViewModel::class.java)) {
            return NotesViewModel(dao,dao2) as T
        }
        throw IllegalArgumentException("Unknown ViewModel")
    }
}
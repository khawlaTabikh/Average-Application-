package com.example.newproject


import android.annotation.SuppressLint
import android.widget.Toast
import androidx.databinding.InverseMethod
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.map
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch


class NotesViewModel(val dao: NotesDAO,val dao2:StudentDAO) : ViewModel() {
    var newSubject = ""
    var newMark=""
    var newfn=""
    var newfm=""


    private val Notes: LiveData<List<Notes>> = dao.getAll()

    val avg: LiveData<Double> =(dao.getAvg())
    val avgString: LiveData<String> =avg.map{
            value -> String.format("%.2f",value)
    }

    val NotesString: LiveData<String> = Notes.map {
            Notes -> formatNotes(Notes)
    }
    @SuppressLint("SuspiciousIndentation")
    fun addStudent(){
        viewModelScope.launch {
        val student =Student()
        student.firstName=newfn
        student.familyName=newfm
            if(student.firstName!="" && student.familyName!="")
             dao2.insert(student)
    }
    }

    fun deleteallnotes(){viewModelScope.launch {dao.deletedata()}}
   fun  addNotes(){
       viewModelScope.launch {

           val Notes = Notes()
           Notes.Subject = newSubject
           Notes.Mark=newMark
           if(Notes.Subject!="" && Notes.Mark!="")
           { dao.insert(Notes)}
       }
   }

    fun formatNotes(Notes: List<Notes>): String {
        return Notes.fold("") {
                str, item -> str + '\n' + formatNote(item)
        }
    }
    fun formatNote(Note: Notes): String {
        var str = " ${Note.Subject}              "
        str +=  " ${Note.Mark}"+ '\n'
        return str
    }
}
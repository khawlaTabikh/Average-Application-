package com.example.newproject


import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey


@Entity(tableName ="Student_table")
data class Student(
    @PrimaryKey(autoGenerate = true)
    var StudentId: Long = 0L,
    @ColumnInfo(name = "First_name")
    var firstName: String = "",
    @ColumnInfo(name = "Family_name")
    var familyName: String = "",
)

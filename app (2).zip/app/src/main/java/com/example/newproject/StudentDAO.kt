package com.example.newproject
import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
@Dao
interface StudentDAO {
    @Insert
    suspend fun insert(student: Student)
    @Update
    suspend fun update(student: Student)
    @Query("DELETE FROM Student_table")
    fun deletedata()
    @Delete
    suspend fun delete(student: Student)
    @Query("SELECT * FROM Student_table WHERE StudentId = :key")
    fun get(key: Long): LiveData<Student>
    @Query("SELECT * FROM Student_table ORDER BY StudentId DESC")
    fun getAll(): LiveData<List<Student>>
}
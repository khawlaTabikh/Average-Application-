package com.example.newproject


import androidx.databinding.InverseMethod
import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.newproject.Student
@Dao
interface NotesDAO {
    @Insert
    suspend fun insert(notes: Notes)

    @Update
    suspend fun update(notes: Notes)


    @Query("DELETE FROM Notes_table")
    suspend fun deletedata()

    @Delete
    suspend fun delete(notes: Notes)


    @Query("SELECT * FROM Notes_table ORDER BY Mark DESC")
    fun getAll(): LiveData<List<Notes>>

    @Query("SELECT AVG(Mark)  From Notes_table ")
    fun getAvg(): LiveData<Double>



}

package com.example.newproject



import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "Notes_table")
data class Notes(
   @PrimaryKey()
    var Subject: String = "",
    @ColumnInfo(name = "Mark")
    var Mark: String = "",
)